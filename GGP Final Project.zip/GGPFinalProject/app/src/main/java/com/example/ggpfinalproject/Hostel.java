package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Hostel extends AppCompatActivity {

    EditText Name, Branch, Category, Gender, Mobile;
    Button signup, signin;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hostel);

        Name = findViewById(R.id.Name);
        Branch = findViewById(R.id.Branch);
        Category = findViewById(R.id.Category);
        Gender = findViewById(R.id.Gender);
        Mobile = findViewById(R.id.guardian);


        signup = findViewById(R.id.signup);
        signin = findViewById(R.id.signin);

        DB = new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String name1 = Name.getText().toString();
                String branch1 = Branch.getText().toString();
                String category1 = Category.getText().toString();
                String gender1 = Gender.getText().toString();
                String mobile1 = Mobile.getText().toString();

                if(TextUtils.isEmpty(name1) || TextUtils.isEmpty(branch1) || TextUtils.isEmpty(category1)|| TextUtils.isEmpty(gender1)|| TextUtils.isEmpty(mobile1))
                {
                    Toast.makeText(Hostel.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    Boolean insert2 = DB.insertData2(name1, branch1, category1,gender1,mobile1);
                    if (insert2 == true)
                    {
                        Toast.makeText(Hostel.this, "Student Registration for Hostel Successfully", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(Hostel.this, "Student Registration for Hostel Not Successfully", Toast.LENGTH_SHORT).show();
                    }
                }

                }

        });

    }
}