package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class teaching_staff extends AppCompatActivity {

    RelativeLayout teaching_staff, feedback_form, University_Guidelines;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_design);

        teaching_staff = findViewById(R.id.teaching_staff_id);
        feedback_form = findViewById(R.id.feedback_form_id);
        University_Guidelines = findViewById(R.id.University_Guidelines_id);
    }


    public void teaching_staff_onclick(View view)
    {
        gotoUrl("https://ggpbilaspur.ac.in/pages/AcademicTeachingStaff.html");


    }

    public void feedback_form_onclick(View view)
    {
        gotoUrl("https://ggpbilaspur.ac.in/Download%20Content/Academic%20Feedback/Feedback%20Form.pdf");

    }

    public void University_Guidelines_onclick(View view)
    {
        gotoUrl1("https://ggpbilaspur.ac.in/Download%20Content/Academic%20Feedback/Feedback%20Form.pdf");

    }

    private void gotoUrl(String s)
    {
        Uri uri = Uri.parse(s);
        Intent send = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(send);
    }

    private void gotoUrl1(String s1)
    {
        Uri uri1 = Uri.parse(s1);
        Intent send = new Intent(Intent.ACTION_VIEW, uri1);
        startActivity(send);
    }

    private void gotoUrl2(String s2)
    {
        Uri uri2 = Uri.parse(s2);
        Intent send = new Intent(Intent.ACTION_VIEW, uri2);
        startActivity(send);
    }

}
