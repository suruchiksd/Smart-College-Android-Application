package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Syllabus extends AppCompatActivity {

    Button Semester1, Semester2, Semester3,Semester4,Semester5,Semester6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_syllabus);


        Semester1 = findViewById(R.id.Semester1);
        Semester2 = findViewById(R.id.Semester2);
        Semester3 = findViewById(R.id.Semester3);
        Semester4 = findViewById(R.id.Semester4);
        Semester5 = findViewById(R.id.Semester5);
        Semester6 = findViewById(R.id.Semester6);

    }


    public void Sem1_onclick(View view)
    {
        gotoUrl1("https://www.csvtu.ac.in/prev/pdf_doc/I_sem_CS_Dip.pdf");


    }

    public void Sem2_onclick(View view)
    {
        gotoUrl2("https://www.csvtu.ac.in/prev/pdf_doc/II_sem_CS_Dip.pdf");

    }

    public void Sem3_onclick(View view)
    {
        gotoUrl3("https://www.csvtu.ac.in/prev/pdf_doc/III_sem_CS_Dip.pdf");

    }

    public void Sem4_onclick(View view)
    {
        gotoUrl4("https://www.csvtu.ac.in/prev/pdf_doc/IV_sem_CS_Dip.pdf");

    }

    public void Sem5_onclick(View view)
    {
        gotoUrl5("https://www.csvtu.ac.in/prev/pdf_doc/syllabus_V_sem_CS_Dip.pdf");

    }

    public void Sem6_onclick(View view)
    {
        gotoUrl6("https://www.csvtu.ac.in/prev/pdf_doc/syllabus_VI_sem_CS_Dip.pdf");

    }





    private void gotoUrl1(String s1)
    {
        Uri uri1 = Uri.parse(s1);
        Intent send = new Intent(Intent.ACTION_VIEW, uri1);
        startActivity(send);
    }

    private void gotoUrl2(String s2)
    {
        Uri uri2 = Uri.parse(s2);
        Intent send = new Intent(Intent.ACTION_VIEW, uri2);
        startActivity(send);
    }

    private void gotoUrl3(String s3)
    {
        Uri uri3 = Uri.parse(s3);
        Intent send = new Intent(Intent.ACTION_VIEW, uri3);
        startActivity(send);
    }

    private void gotoUrl4(String s4)
    {
        Uri uri4 = Uri.parse(s4);
        Intent send = new Intent(Intent.ACTION_VIEW, uri4);
        startActivity(send);
    }

    private void gotoUrl5(String s5)
    {
        Uri uri5 = Uri.parse(s5);
        Intent send = new Intent(Intent.ACTION_VIEW, uri5);
        startActivity(send);
    }

    private void gotoUrl6(String s6)
    {
        Uri uri6 = Uri.parse(s6);
        Intent send = new Intent(Intent.ACTION_VIEW, uri6);
        startActivity(send);
    }


    }
