package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class notice_dashboard extends AppCompatActivity {

    Button admin, student, syllabus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_dashboard);

        admin = findViewById(R.id.notice_upload);
        student = findViewById(R.id.student_upload);
        syllabus = findViewById(R.id.syllabus_download);

        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent send2 = new Intent(notice_dashboard.this, notice_upload.class);
                startActivity(send2);
            }
        });

        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent send2 = new Intent(notice_dashboard.this, Userlist.class);
                startActivity(send2);
            }
        });

        syllabus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent send2 = new Intent(notice_dashboard.this, Syllabus.class);
                startActivity(send2);
            }
        });

    }
}