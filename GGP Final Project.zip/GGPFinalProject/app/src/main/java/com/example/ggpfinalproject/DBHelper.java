package com.example.ggpfinalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {

        super(context, "login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users(username Text primary key, password Text)");
        db.execSQL("create table notice(title Text primary key, content Text, Teacher Text)");
        db.execSQL("create table hostel(name Text primary key, branch Text, category Text, gender text, mobile Text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
        db.execSQL("drop table if exists notice");
        db.execSQL("drop table if exists hostel");
        onCreate(db);
    }

    public Boolean insertData(String username, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values1 = new ContentValues();

        values1.put("username", username);
        values1.put("password", password);

        long result = db.insert("users", null, values1);

        if (result == -1) {

            return false;
        } else {
            return true;
        }
    }

    public Boolean insertData1(String title1, String content, String Teacher)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values2 = new ContentValues();

        values2.put("title", title1);
        values2.put("content", content);
        values2.put("Teacher", Teacher);

        long result1 = db.insert("notice", null, values2);

        if (result1 == -1) {

            return false;
        }
        else
        {
            return true;
        }


    }

    public Boolean insertData2(String name1, String branch1, String category1, String gender1, String mobile1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values3 = new ContentValues();

        values3.put("name", name1);
        values3.put("branch", branch1);
        values3.put("category", category1);
        values3.put("gender", gender1);
        values3.put("mobile", mobile1);

        long result2 = db.insert("hostel", null, values3);

        if (result2 == -1) {

            return false;
        }
        else
        {
            return true;
        }


    }

    public Cursor getdata()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from notice", null);
        return cursor;
    }


    public Boolean checkusername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=?", new String[]{username});

        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }

    }


    public Boolean checkusernamepassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username= ? and password= ?", new String[]{username, password});

        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }

    }

}
