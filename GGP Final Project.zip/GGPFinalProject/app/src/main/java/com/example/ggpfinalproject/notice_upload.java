package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class notice_upload extends AppCompatActivity
{

    EditText title, message, faculty;
    Button upload;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_upload);

        title = findViewById(R.id.title1);
        message = findViewById(R.id.message1);
        faculty = findViewById(R.id.faculty1);

        upload = findViewById(R.id.signin1);

        DB = new DBHelper(this);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String title1 = title.getText().toString();
                String content = message.getText().toString();
                String Teacher = faculty.getText().toString();

                if (TextUtils.isEmpty(title1) || TextUtils.isEmpty(content) || TextUtils.isEmpty(Teacher))
                {
                    Toast.makeText(notice_upload.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Boolean insert1 = DB.insertData1(title1, content, Teacher);
                    if (insert1 == true)
                    {
                        Toast.makeText(notice_upload.this, "Notice Uploaded Successfully", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(notice_upload.this, "Notice Upload Failed", Toast.LENGTH_SHORT).show();
                    }
                }


            }

        });
    }
    }
