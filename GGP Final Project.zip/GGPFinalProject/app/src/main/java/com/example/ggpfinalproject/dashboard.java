package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class dashboard extends AppCompatActivity {


    RelativeLayout institute, academic, notice, gallery, Contact_us, hostel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        institute = findViewById(R.id.institute_layout);
        academic = findViewById(R.id.academic_layout);
        notice = findViewById(R.id.notice_layout);
        gallery = findViewById(R.id.gallery_layout);
        Contact_us = findViewById(R.id.contact_us_layout);
        hostel = findViewById(R.id.hostel_layout);

    }


    public void insti_onclick(View view)
    {
        Intent send = new Intent(dashboard.this, Institute_Design.class);
        startActivity(send);
    }

    public void academic_deign_onclick(View view)
    {

        Intent send1 = new Intent(dashboard.this, teaching_staff.class);
        startActivity(send1);
    }

    public void notice_design_onclick(View view)
    {
        Intent send2 = new Intent(dashboard.this, notice_dashboard.class);
        startActivity(send2);
    }

    public void gallery_design_onclick(View view)
    {
        Intent send3 = new Intent(dashboard.this, Gallery_Main.class);
        startActivity(send3);
    }

    public void contact_us_onclick(View view)
    {
        Intent send4 = new Intent(dashboard.this, Contact.class);
        startActivity(send4);
    }

    public void hostel_design_onclick(View view)
    {
        Intent send5 = new Intent(dashboard.this, Hostel.class);
        startActivity(send5);
    }
}