package com.example.ggpfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Institute_Design extends AppCompatActivity {

    RelativeLayout about_institute, principal_desk, about_bilaspur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_institute_design);

        principal_desk = findViewById(R.id.principal_desk);
        about_institute = findViewById(R.id.about_institute);
        about_bilaspur = findViewById(R.id.about_bilaspur);
    }

    public void principal_desk_onclick(View view)
    {
        Intent send = new Intent(Institute_Design.this, principal_desk_page.class);
        startActivity(send);
    }

    public void about_bilaspur_onclick(View view)
    {
        Intent send = new Intent(Institute_Design.this, about_bilaspur_page.class);
        startActivity(send);
    }

    public void about_institute_onclick(View view)
    {
        Intent send = new Intent(Institute_Design.this, about_institute_page.class);
        startActivity(send);
    }


}